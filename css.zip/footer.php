<footer id="main-footer" class="container-fluid">
         <div class="vc_row wpb_row st bg-holder vc_custom_1457429455924 vc_row-has-fill">
            <div class='container '>
               <div class='row'>
                  <div class="wpb_column column_container col-md-3 vc_custom_1422334137119">
                     <div class="vc_column-inner wpb_wrapper">
                        <div class="wpb_text_column wpb_content_element ">
                           <div class="wpb_wrapper">
                              <p><img class="alignnone size-full wp-image-11123" src="images/logo-white.png" alt="logo-white" width="110" height="40" /></p>
                              <p>Booking, reviews and advices on hotels, resorts, flights, vacation rentals, travel packages, and lots more!</p>
                           </div>
                        </div>
                        <div class="wpb_raw_code wpb_content_element wpb_raw_html">
                           <div class="wpb_wrapper">
                              <ul class="list list-horizontal list-space">
                                 <li>
                                    <a href="#" class="fa fa-facebook box-icon-normal round animate-icon-bottom-to-top"></a>
                                 </li>
                                 <li>
                                    <a href="#" class="fa fa-twitter box-icon-normal round animate-icon-bottom-to-top"></a>
                                 </li>
                                 <li>
                                    <a href="#" class="fa fa-google-plus box-icon-normal round animate-icon-bottom-to-top"></a>
                                 </li>
                                 <li>
                                    <a href="#" class="fa fa-linkedin box-icon-normal round animate-icon-bottom-to-top"></a>
                                 </li>
                                 <li>
                                    <a href="#" class="fa fa-pinterest box-icon-normal round animate-icon-bottom-to-top"></a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="wpb_column column_container col-md-3 vc_custom_1422334156180">
                     <div class="vc_column-inner wpb_wrapper">
                        <div class="wpb_text_column wpb_content_element ">
                           <div class="wpb_wrapper">
                              <!-- MailChimp for WordPress v2.3.16 - https://wordpress.org/plugins/mailchimp-for-wp/ -->
                              <div id="mc4wp-form-2" class="form mc4wp-form">
                                 <form method="post" >
                                    <h4>Newsletter</h4>
                                    <label>Enter your E-mail Address</label>
                                    <input type="email" name="EMAIL" class="form-control">
                                    <p class="mt5"><small>*We Never Send Spam</small>
                                    </p>
                                    <input type="submit" value="Subscribe" class="btn btn-primary">
                                    <div style="position: absolute; left: -5000px;"><input type="text" name="_mc4wp_ho_6b633c0a12ecd87bd4089deb69f7edd4" value="" tabindex="-1" autocomplete="off" /></div>
                                    <input type="hidden" name="_mc4wp_timestamp" value="1487265576" /><input type="hidden" name="_mc4wp_form_id" value="0" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-2" /><input type="hidden" name="_mc4wp_form_submit" value="1" /><input type="hidden" name="_mc4wp_form_nonce" value="bb2af00e32" />
                                 </form>
                              </div>
                              <!-- / MailChimp for WordPress Plugin -->
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="wpb_column column_container col-md-2 vc_custom_1422334176021">
                     <div class="vc_column-inner wpb_wrapper">
                        <div class="wpb_raw_code wpb_content_element wpb_raw_html">
                           <div class="wpb_wrapper">
                              <ul class="list list-footer">
                                 <li><a href="#">About US</a>
                                 </li>
                                 <li><a href="#">Press Centre</a>
                                 </li>
                                 <li><a href="#">Best Price Guarantee</a>
                                 </li>
                                 <li><a href="#">Travel News</a>
                                 </li>
                                 <li><a href="#">Jobs</a>
                                 </li>
                                 <li><a href="#">Privacy Policy</a>
                                 </li>
                                 <li><a href="#">Terms of Use</a>
                                 </li>
                                 <li><a href="#">Feedback</a>
                                 </li>
                                 <li><a href="./how-it-works/">How it words ?</a>
                                 </li>
                                 <li><a href="./become-a-partner/">Become a Partner</a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="wpb_column column_container col-md-4 vc_custom_1422334188578">
                     <div class="vc_column-inner wpb_wrapper">
                        <div class="wpb_raw_code wpb_content_element wpb_raw_html">
                           <div class="wpb_wrapper">
                              <h4>Have Questions?</h4>
                              <h4 class="text-color">+27 81 740 0107</h4>
                              <h4><a class="text-color">info@heystranger.co.za</a></h4>
                              <p>24/7 Dedicated Customer Support</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--End .row-->
            </div>
            <!--End .container-->
         </div>
      </footer>