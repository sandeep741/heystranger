<div class="footer text-muted">
                     &copy; 2016. <a href="#">Global_MLM</a> by <a href="#" target="_blank">Global Soft Web Technologies</a>
</div>