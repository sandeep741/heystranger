<div class="footer text-muted">
                     &copy; 2016. <a href="#">Test</a> 
</div>